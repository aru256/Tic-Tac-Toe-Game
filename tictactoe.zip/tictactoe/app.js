let cells = [];
const boardEl = document.getElementById('board');
const overlayEl = document.getElementById('winOverlay');
const statusEl = document.getElementById('status');
const resetBtn = document.getElementById('reset');
const newGameBtn = document.getElementById('newGame');
const sizeModal = document.getElementById('sizeModal');
const boardSizeSelect = document.getElementById('boardSize');
const startGameBtn = document.getElementById('startGame');

let size = 3;
let board = [];
let currentPlayer = 'X';
let isGameOver = false;
let winLines = [];

function showModal(){ sizeModal.classList.remove('hidden'); }
function hideModal(){ sizeModal.classList.add('hidden'); }

function setStatus(text){ statusEl.textContent = text; }

function initBoard(n){
  size = n;
  board = Array(size * size).fill(null);
  isGameOver = false;
  currentPlayer = 'X';
  winLines = computeWinLines(size);

  // Grid columns
  boardEl.style.gridTemplateColumns = `repeat(${size}, 1fr)`;

  // Clear
  boardEl.querySelectorAll('.cell').forEach(el => el.remove());
  clearWinOverlay();

  // Generate cells
  cells = [];
  for(let i = 0; i < size * size; i++){
    const btn = document.createElement('button');
    btn.className = 'cell';
    btn.setAttribute('data-cell', '');
    btn.setAttribute('role', 'gridcell');
    btn.setAttribute('aria-label', `Cell ${i+1}`);
    btn.addEventListener('click', () => handleCellClick(i, btn));
    btn.tabIndex = 0;
    btn.addEventListener('keydown', (e) => {
      if(e.key === 'Enter' || e.key === ' '){ e.preventDefault(); btn.click(); }
    });
    boardEl.appendChild(btn);
    cells.push(btn);
  }

  setStatus(`Player ${currentPlayer}'s turn`);
}

function computeWinLines(n){
  const lines = [];
  // Rows
  for(let r=0; r<n; r++){
    const line = [];
    for(let c=0; c<n; c++) line.push(r*n + c);
    lines.push(line);
  }
  // Cols
  for(let c=0; c<n; c++){
    const line = [];
    for(let r=0; r<n; r++) line.push(r*n + c);
    lines.push(line);
  }
  // Diagonal (TL-BR)
  const d1 = [];
  for(let i=0; i<n; i++) d1.push(i*n + i);
  lines.push(d1);
  // Diagonal (TR-BL)
  const d2 = [];
  for(let i=0; i<n; i++) d2.push(i*n + (n-1-i));
  lines.push(d2);
  return lines;
}

function handleCellClick(idx, cell){
  if(isGameOver || board[idx]) return;
  board[idx] = currentPlayer;
  cell.textContent = currentPlayer;
  cell.classList.add(currentPlayer.toLowerCase());

  const win = getWinner();
  if(win){
    isGameOver = true;
    drawWinLine(win.line);
    win.line.forEach(i => cells[i].classList.add('win'));
    setStatus(`Winner: ${win.player} 🎉`);
    setTimeout(() => navigateToWinner(win.player), 900);
    return;
  }

  if(board.every(v => v)){
    isGameOver = true;
    setStatus(`It's a draw 🤝`);
    setTimeout(() => navigateToWinner('Draw'), 700);
    return;
  }

  currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
  setStatus(`Player ${currentPlayer}'s turn`);
}

function getWinner(){
  for(const line of winLines){
    const val = board[line[0]];
    if(!val) continue;
    if(line.every(i => board[i] === val)) return { player: val, line };
  }
  return null;
}

function clearWinOverlay(){
  while(overlayEl.firstChild) overlayEl.removeChild(overlayEl.firstChild);
}

function drawWinLine(line){
  // Compute centers of first and last winning cells in SVG 0..100 coords
  const rect = boardEl.getBoundingClientRect();
  const pad = 16; // matches CSS inset for overlay
  const innerW = rect.width - 2*pad;
  const innerH = rect.height - 2*pad;
  const cellW = (innerW - (size-1)*12) / size; // 12px gap from CSS
  const cellH = (innerH - (size-1)*12) / size;

  const idxToCenter = (idx) => {
    const r = Math.floor(idx / size);
    const c = idx % size;
    const x = pad + c*(cellW+12) + cellW/2;
    const y = pad + r*(cellH+12) + cellH/2;
    // convert to SVG viewBox 0..100
    return {
      x: (x - pad) / innerW * 100,
      y: (y - pad) / innerH * 100
    };
  };

  const a = idxToCenter(line[0]);
  const b = idxToCenter(line[line.length-1]);

  const svgLine = document.createElementNS('http://www.w3.org/2000/svg','line');
  svgLine.setAttribute('x1', String(a.x));
  svgLine.setAttribute('y1', String(a.y));
  svgLine.setAttribute('x2', String(b.x));
  svgLine.setAttribute('y2', String(b.y));
  overlayEl.appendChild(svgLine);
}

function resetBoard(){
  board = Array(size * size).fill(null);
  isGameOver = false;
  currentPlayer = 'X';
  clearWinOverlay();
  cells.forEach(c => { c.textContent=''; c.classList.remove('x','o','win'); });
  setStatus(`Player ${currentPlayer}'s turn`);
}

function newGame(){
  // Show modal to choose a new size
  showModal();
}

function navigateToWinner(result){
  try {
    localStorage.setItem('tictactoe_result', JSON.stringify({ result, size }));
  } catch {}
  window.location.href = 'winner.html';
}

// Events
resetBtn.addEventListener('click', resetBoard);
newGameBtn.addEventListener('click', newGame);
startGameBtn.addEventListener('click', () => {
  const n = parseInt(boardSizeSelect.value, 10) || 3;
  hideModal();
  initBoard(n);
});

// Start
showModal(); 