(function(){
  let result = 'Unknown';
  let size = 3;
  try{
    const raw = localStorage.getItem('tictactoe_result');
    if(raw){ const parsed = JSON.parse(raw); result = parsed.result || result; size = parsed.size || size; }
  }catch{}

  const winnerText = document.getElementById('winnerText');
  const details = document.getElementById('details');
  const playAgain = document.getElementById('playAgain');
  const quit = document.getElementById('quit');

  if(result === 'Draw'){
    winnerText.textContent = 'It\'s a Draw!';
    details.textContent = `Board: ${size} × ${size}`;
  } else {
    winnerText.textContent = `Winner: ${result}`;
    details.textContent = `Board: ${size} × ${size}`;
  }

  playAgain.addEventListener('click', () => {
    // Go back to main page; selection modal will show
    window.location.href = 'index.html';
  });

  quit.addEventListener('click', () => {
    // Clear result and go to a blank page or back
    try{ localStorage.removeItem('tictactoe_result'); }catch{}
    window.location.href = 'index.html';
  });
})(); 